// src/pages/TVDisplayPage.js
import React from 'react';
import Header from '../components/Header'; // Assuming you have a Header component
import Footer from '../components/Footer'; // Assuming you have a Footer component
import '../styles/TVDisplay.css';

const TVDisplayPage = () => {
  const upcomingPatient = { bill: '1048', name: 'Priya', time: '10:40 am' };
  const currentPatient = { bill: '1008', name: 'Madhu', time: '10:30 am' };
  const waitingList = Array.from({ length: 12 }, (_, i) => ({
    name: 'jeshy',
    bill: '1028',
    number: i + 3,
  }));

  return (
    <div className="tv-container">
      {/* The header is now handled by the Header component with hideable set to true */}
      <Header hideable={true} /> 
      
      <div className="tv-main">
        <div className="tv-cards">
          <div className="tv-card yellow">
            <div className="icon">👤</div>
            <div className="title">Upcoming Patient</div>
            <div className="bill">{upcomingPatient.bill}</div>
            <div className="name">{upcomingPatient.name}</div>
            <div className="added">Added: {upcomingPatient.time}</div>
          </div>
          <div className="tv-card green">
            <div className="icon">🧍‍♂️</div>
            <div className="title">Currently Attending</div>
            <div className="bill">{currentPatient.bill}</div>
            <div className="name">{currentPatient.name}</div>
            <div className="added">Added at: {currentPatient.time}</div>
          </div>
        </div>

        <div className="tv-waiting-grid">
          {waitingList.map((item, index) => (
            <div className="tv-waiting-card" key={index}>
              <div className="name">{item.name}</div>
              <div className="bill">Bill : {item.bill}</div>
              <div className="number">#{item.number}</div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Assuming a Footer component is used, if not, you can place the footer markup here */}
      <Footer /> 
    </div>
  );
};

export default TVDisplayPage;