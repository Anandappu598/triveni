import React from 'react';

const Footer = () => (
  <footer className="footer">
    <hr />
    <p>© Developed by Jeshwanth</p>
  </footer>
);

export default Footer;
