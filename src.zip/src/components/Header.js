// src/components/Header.js
import React from 'react';
import { NavLink } from 'react-router-dom';
import './Header.css'; // Make sure to import the CSS file

const navItems = [
  { name: 'Reception', path: '/reception', icon: '/assets/icons/reception.png' },
  { name: 'TV Display', path: '/tvdisplay', icon: '/assets/icons/tvdisplay.png' },
  { name: 'Scan Room', path: '/scanroom', icon: '/assets/icons/scanroom.png' },
];

const Header = ({ hideable = false }) => {
  const headerClass = `app-header ${hideable ? 'hover-hidden' : ''}`;

  return (
    <header className={headerClass}>
      {/* Logo + Title */}
      <div className="header-left">
        <img src="/assets/logo.png" alt="Logo" className="logo" />
        <h1 className="clinic-name">Triveni Diagnostics And Imaging Centre</h1>
      </div>

      {/* Navigation */}
      <nav className="header-nav">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `nav-link ${isActive ? 'active' : ''}`
            }
          >
            <img src={item.icon} alt={item.name} className="nav-icon" />
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>
    </header>
  );
};

export default Header;